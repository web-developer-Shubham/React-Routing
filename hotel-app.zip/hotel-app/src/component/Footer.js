import   React from 'react'

const Footer = ()=>{
return(
    <div>
    <hr/>
     <center >&copy; &nbsp;Routing and Bootstrap- By Shubham Saxena</center>
     </div>
   
)

}


export default Footer;